'use stirct';

module.exports = require('./async').everyLimit;
