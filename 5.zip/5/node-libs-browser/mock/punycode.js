exports.ucs2 = {};
exports.encode = exports.decode =
exports.ucs2.encode = exports.ucs2.decode =
exports.toUnicode = exports.toASCII =
function (s) { return s };
exports.version = "0.0.0";