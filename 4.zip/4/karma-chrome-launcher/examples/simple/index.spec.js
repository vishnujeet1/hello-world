/* eslint-env mocha */

describe('ChromeLauncher', function () {
  it('works', function () {
    return 1 + 1 === 2
  })
})
