Check that your description matches the automatic change-log format:
http://karma-runner.github.io/latest/dev/git-commit-msg.html
then delete this reminder.
