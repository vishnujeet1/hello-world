import { mergeAll } from './mergeAll';
export function concatAll() {
    return mergeAll(1);
}
//# sourceMappingURL=concatAll.js.map