import { AsapAction } from './AsapAction';
import { AsapScheduler } from './AsapScheduler';
export const asap = new AsapScheduler(AsapAction);
//# sourceMappingURL=asap.js.map