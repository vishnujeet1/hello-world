import { WebSocketSubject } from './WebSocketSubject';
export function webSocket(urlConfigOrSource) {
    return new WebSocketSubject(urlConfigOrSource);
}
//# sourceMappingURL=webSocket.js.map