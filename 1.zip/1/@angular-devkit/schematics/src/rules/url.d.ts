import { Source } from '../engine/interface';
export declare function url(urlString: string): Source;
