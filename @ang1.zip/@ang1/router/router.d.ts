/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { ROUTER_FORROOT_GUARD as ɵangular_packages_router_router_a, RouterInitializer as ɵangular_packages_router_router_h, createRouterScroller as ɵangular_packages_router_router_c, getAppInitializer as ɵangular_packages_router_router_i, getBootstrapListener as ɵangular_packages_router_router_j, provideForRootGuard as ɵangular_packages_router_router_e, provideLocationStrategy as ɵangular_packages_router_router_d, provideRouterInitializer as ɵangular_packages_router_router_k, rootRoute as ɵangular_packages_router_router_g, routerNgProbeToken as ɵangular_packages_router_router_b, setupRouter as ɵangular_packages_router_router_f } from './src/router_module';
export { RouterScroller as ɵangular_packages_router_router_n } from './src/router_scroller';
export { Tree as ɵangular_packages_router_router_l, TreeNode as ɵangular_packages_router_router_m } from './src/utils/tree';
