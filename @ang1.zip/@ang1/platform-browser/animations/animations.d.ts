/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { BaseAnimationRenderer as ɵangular_packages_platform_browser_animations_animations_g } from './src/animation_renderer';
export { BROWSER_ANIMATIONS_PROVIDERS as ɵangular_packages_platform_browser_animations_animations_e, BROWSER_NOOP_ANIMATIONS_PROVIDERS as ɵangular_packages_platform_browser_animations_animations_f, InjectableAnimationEngine as ɵangular_packages_platform_browser_animations_animations_a, instantiateDefaultStyleNormalizer as ɵangular_packages_platform_browser_animations_animations_c, instantiateRendererFactory as ɵangular_packages_platform_browser_animations_animations_d, instantiateSupportedAnimationDriver as ɵangular_packages_platform_browser_animations_animations_b } from './src/providers';
